#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <time.h>
#include "mxml-private.h"
#include "mxml.h"

#include "onvif_probe.xml"
#include "lib/base64.h"
#include "lib/sha1.h"

/* 从技术层面来说，通过单播、多播、广播三种方式都能探测到IPC，但多播最具实用性*/
#define COMM_TYPE_UNICAST 1   // 单播
#define COMM_TYPE_MULTICAST 2 // 多播
#define COMM_TYPE_BROADCAST 3 // 广播
#define COMM_TYPE COMM_TYPE_MULTICAST

/* 发送探测消息（Probe）的目标地址、端口号 */
#if COMM_TYPE == COMM_TYPE_UNICAST
#define CAST_ADDR "100.100.100.15" // 单播地址，预先知道的IPC地址
#elif COMM_TYPE == COMM_TYPE_MULTICAST
#define CAST_ADDR "239.255.255.250" // 多播地址，固定的239.255.255.250
#elif COMM_TYPE == COMM_TYPE_BROADCAST
#define CAST_ADDR "100.100.100.255" // 广播地址
#endif
#define CAST_PORT 3702 // 端口号
/****************************************************************
 2022-09-16 author:leo.liu 说明:onvif 地址信息
*****************************************************************/
static struct sockaddr_in onvif_multi_addr;
/****************************************************************
**@日期: 2022-09-16
**@作者: leo.liu
**@功能:打开onvif陶介子
*****************************************************************/
static bool onvif_socket_discover_open(int *handle_id, char *ip, int port, bool broadcast)
{
        /****************************************************************
        2022-09-16 author:leo.liu 说明:建立数据报套接字
        *****************************************************************/
        int socket_fd = socket(AF_INET, SOCK_DGRAM, 0);
        if (socket_fd < 0)
        {
                printf("#############socket error############# \n");
                return false;
        }
        if (broadcast == true)
        {
                int optval = 1;
                setsockopt(socket_fd, SOL_SOCKET, SO_BROADCAST, (const char *)&optval, sizeof(int));
        }
        /****************************************************************
        2022-09-16 author:leo.liu 说明:搜索IPC：使用UDP向指定地址发送探测消息(Probe)
        *****************************************************************/
        onvif_multi_addr.sin_family = AF_INET;
        onvif_multi_addr.sin_port = htons(port);
        onvif_multi_addr.sin_addr.s_addr = inet_addr(ip);
        *handle_id = socket_fd;
        return true;
}
/****************************************************************
**@日期: 2022-09-17
**@作者: leo.liu
**@功能:连接设备tcp
*****************************************************************/
static bool onvif_socket_device_open(int *handle_id, char *ip, int port)
{
        int socket_fd = socket(AF_INET, SOCK_STREAM, 0);
        if (socket_fd < 0)
        {
                printf("#############socket error tcp############# \n");
                return false;
        }
        struct sockaddr_in server_addr;
        bzero(&server_addr, sizeof(server_addr)); // 初始化服务器地址
        server_addr.sin_family = AF_INET;
        server_addr.sin_port = htons(port);
        server_addr.sin_addr.s_addr = inet_addr(ip);
        /****************************************************************
        2022-09-17 author:leo.liu 说明:  主动连接服务器
        *****************************************************************/
        int err_log = connect(socket_fd, (struct sockaddr *)&server_addr, sizeof(server_addr));
        if (err_log != 0)
        {
                printf("connnetcd :%s failed \n", ip);
                return false;
        }
        *handle_id = socket_fd;
        return true;
}

/****************************************************************
**@日期: 2022-09-16
**@作者: leo.liu
**@功能:关闭
*****************************************************************/
static bool onvif_socket_close(int handle_id)
{
        if (handle_id < 0)
        {
                return false;
        }
        close(handle_id);
        return true;
}
/****************************************************************
**@日期: 2022-09-16
**@作者: leo.liu
**@功能:发送探测消息
*****************************************************************/
static bool onvif_discover_send_msg(int hand_id, const char *msg)
{
        int ret = sendto(hand_id, msg, strlen(msg), 0, (struct sockaddr *)&onvif_multi_addr, sizeof(onvif_multi_addr));
        return ret < 0 ? false : true;
}
/****************************************************************
**@日期: 2022-09-17
**@作者: leo.liu
**@功能:解析文本中的xadds
*****************************************************************/
static bool xml_to_xaddres_parse(const char *xml, char *xaddres, int len)
{
        bool reslut = false;
        mxml_node_t *root = mxmlLoadString(NULL, xml, MXML_NO_CALLBACK);
        if (root != NULL)
        {
                mxml_node_t *env_envelope = mxmlFindElement(root, root, "env:Envelope", NULL, NULL, MXML_DESCEND);
                if (env_envelope != NULL)
                {
                        mxml_node_t *env_body = mxmlFindElement(env_envelope, root, "env:Body", NULL, NULL, MXML_DESCEND);
                        if (env_body != NULL)
                        {
                                mxml_node_t *xaddrs = mxmlFindElement(env_body, root, "d:XAddrs", NULL, NULL, MXML_DESCEND);
                                if ((xaddrs != NULL) && (xaddrs->child != NULL) && (xaddrs->child->value.text.string != NULL))
                                {
                                        printf(" XAddrs:%s \n", xaddrs->child->value.text.string);
                                        strncpy(xaddres, xaddrs->child->value.text.string, len);
                                        reslut = true;
                                }
                        }
                }
        }
        mxmlDelete(root);
        return reslut;
}
static bool onvif_receive_msg(int hand_id, char *recv_buff, int recv_len, int timeout_ms)
{
        bool reslut = false;
        do
        {
                /****************************************************************
                2022-09-16 author:leo.liu 说明:使用select 探测超时
                *****************************************************************/
                fd_set read_fd_set;
                struct timeval timeout;
                FD_ZERO(&read_fd_set);
                FD_SET(hand_id, &read_fd_set);
                timeout.tv_sec = (timeout_ms / 1000);
                timeout.tv_usec = (timeout_ms % 1000) * 1000;
                select(hand_id + 1, &read_fd_set, NULL, NULL, &timeout);

                if (FD_ISSET(hand_id, &read_fd_set) > 0)
                {
                        struct sockaddr_in client_addr;
                        socklen_t len = sizeof(client_addr);
                        memset(&client_addr, 0, sizeof(struct sockaddr));

                        memset(recv_buff, 0, recv_len);
                        int ret = recvfrom(hand_id, recv_buff, recv_len - 1, 0, (struct sockaddr *)&client_addr, &len);
                        reslut = ret > 0 ? true : false;
                        break;
                }
        } while (0);

        return reslut;
}
/****************************************************************
**@日期: 2022-09-17
**@作者: leo.liu
**@功能:监听涩北端信息
*****************************************************************/
static bool onvif_device_receive_msg(int hand_id, char *recv_buff, int recv_len, int timeout_ms)
{
        bool reslut = false;
        do
        {
                /****************************************************************
                2022-09-16 author:leo.liu 说明:使用select 探测超时
                *****************************************************************/
                fd_set read_fd_set;
                struct timeval timeout;
                FD_ZERO(&read_fd_set);
                FD_SET(hand_id, &read_fd_set);
                timeout.tv_sec = (timeout_ms / 1000);
                timeout.tv_usec = (timeout_ms % 1000) * 1000;
                select(hand_id + 1, &read_fd_set, NULL, NULL, &timeout);

                if (FD_ISSET(hand_id, &read_fd_set) > 0)
                {
                        memset(recv_buff, 0, recv_len);
                        int ret = recv(hand_id, recv_buff, recv_len - 1, 0);
                        reslut = ret > 0 ? true : false;
                        break;
                }
        } while (0);

        return reslut;
}
/****************************************************************
**@日期: 2022-09-16
**@作者: leo.liu
**@功能:探测ipc的d:XAddrs
*****************************************************************/
static bool onvif_xaddrs_probe(int hand_id, char *xaddres, int len, int timeout_ms)
{
        bool reslut = true;
        /****************************************************************
        2022-09-16 author:leo.liu 说明:暂时分配4k数据
        *****************************************************************/
        char recv_buff[4 * 1024] = {0};
        if (onvif_receive_msg(hand_id, recv_buff, sizeof(recv_buff), timeout_ms) == true)
        {
                if (xml_to_xaddres_parse(recv_buff, xaddres, len) == false)
                {
                        printf("pares recv buffer to xaddres failed:%s\n", recv_buff);
                        reslut = false;
                }
        }
        return reslut;
}
/****************************************************************
**@日期: 2022-09-17
**@作者: leo.liu
**@功能:产生一个随机数字
*****************************************************************/
static unsigned long nonece_random_number(void)
{
        struct timeval tv;
        gettimeofday(&tv, NULL);
        unsigned long ms = tv.tv_sec * 1000 + tv.tv_usec / 1000;
        /****************************************************************
        2022-09-17 author:leo.liu 说明:获取随机数值
        *****************************************************************/
        srand((unsigned long)time(NULL));
        ms += rand();
        return ms;
}
/****************************************************************
**@日期: 2022-09-17
**@作者: leo.liu
**@功能:获取格林标准时间
*****************************************************************/
static bool created_time_get(char *created, int len)
{
        time_t n;
        time_t t = time(&n);
        struct tm *p = gmtime(&t);
        snprintf(created, len, "%04d-%02d-%02dT%02d:%02d:%02dZ", 1900 + (p->tm_year), 1 + p->tm_mon, p->tm_mday, p->tm_hour, p->tm_min, p->tm_sec);
        return true;
}
/****************************************************************
**@日期: 2022-09-17
**@作者: leo.liu
**@功能:发送鉴权信息
*****************************************************************/
bool ipc_camera_authentication_get(const char *xaddres, const char *useranme, char *passwd, char *out_buffer, int out_len)
{
        char nonect_in[128] = {0};
        char nonect_out[128] = {0};
        int nonect_in_len = 0;
        int nonect_out_len = 0;
        sprintf(nonect_in, "%lu", nonece_random_number());
        // printf("nonect_in=%s \n", nonect_in);
        nonect_in_len = strlen(nonect_in);
        nonect_in_len = (nonect_in_len / 4 + 1) * 4;
        /****************************************************************
        2022-09-17 author:leo.liu 说明:得到base64_decode(nonct);
        *****************************************************************/
        if (base64_decode(nonect_in, nonect_in_len, nonect_out, &nonect_out_len) < 0)
        {
                printf("base64 decode failed \n");
                return false;
        }
        printf("%s nonect_out=%s\n", nonect_in, nonect_out);
        /****************************************************************
        2022-09-17 author:leo.liu 说明:获取日期
        *****************************************************************/
        char created[128] = {0};
        created_time_get(created, sizeof(created));
        //  printf("crated=%s \n", created);
        /****************************************************************
        2022-09-17 author:leo.liu 说明:进行has1
        *****************************************************************/
        char sha1_in[1024] = {0};
        sprintf(sha1_in, "%s+%s+%s", nonect_out, created, passwd);
        //   printf("sha1_in=%s \n", sha1_in);

        unsigned char hash2[20];
        SHA1_CTX ctx;
        SHA1DCInit(&ctx);
        SHA1DCUpdate(&ctx, sha1_in, (unsigned)strlen(sha1_in));
        SHA1DCFinal((unsigned char *)hash2, &ctx);
        for (int j = 0; j < 20; ++j)
        {
                sprintf(sha1_in + (j * 2), "%02x", hash2[j]);
        }
        sha1_in[20 * 2] = 0;
        //   printf("sha1_out=%s \n", sha1_out);

        /****************************************************************
        2022-09-17 author:leo.liu 说明:base64 encode
        *****************************************************************/
        char password_xml[1024];
        int password_xml_len = 0;
        if (base64_encode(sha1_in, strlen(sha1_in), password_xml, &password_xml_len) < 0)
        {
                printf("base64 encode failed \n");
                return false;
        }
        //   printf("password_xml=%s \n", password_xml);
        snprintf(out_buffer, out_len, STREAM_URL_GET_FORMAT, useranme, password_xml, nonect_in, created);
        printf("=====================================================================================\n");
        printf("%s \n", out_buffer);
        printf("=====================================================================================\n");
        return true;
}
/****************************************************************
**@日期: 2022-09-16
**@作者: leo.liu
**@功能: 探测ipc地址
**@参数：rtps地址
*****************************************************************/
bool ipc_camera_search(char rtsp[8][128], int *num)
{
        int onvif_handle_id = 0;
        if (onvif_socket_discover_open(&onvif_handle_id, CAST_ADDR, CAST_PORT, true) == false)
        {
                printf("onvif socket open failed \n");
                return false;
        }
        /****************************************************************
        2022-09-17 author:leo.liu 说明:发送探测设备消息
        *****************************************************************/
        if (onvif_discover_send_msg(onvif_handle_id, onvif_probe) == false)
        {
                printf("onvif send onvif_probe msg failed \n");
                onvif_socket_close(onvif_handle_id);
                return false;
        }
        /****************************************************************
        2022-09-17 author:leo.liu 说明:接受探测的消息
        *****************************************************************/
        char xaddres[128] = {0};
        memset(xaddres, 0, sizeof(xaddres));
        if (onvif_xaddrs_probe(onvif_handle_id, xaddres, sizeof(xaddres), 100) == false)
        {
                printf("onvif recev onvif probe failed \n");
                onvif_socket_close(onvif_handle_id);
                return false;
        }
        onvif_socket_close(onvif_handle_id);

        if (onvif_socket_device_open(&onvif_handle_id, "192.168.170.103", 80) == false)
        {
                printf("onvif socket open failed \n");
                return false;
        }
        char stream_uri[10 * 1024] = {0};
        ipc_camera_authentication_get(xaddres, "admin", "12345", stream_uri, sizeof(stream_uri));

        if (send(onvif_handle_id, profile_probe, strlen(profile_probe), 0) < 0)
        {
                printf("send :%s faield \n",profile_probe);
                onvif_socket_close(onvif_handle_id);
                return false;
        }
        if (onvif_device_receive_msg(onvif_handle_id, stream_uri, sizeof(stream_uri), 1000) == false)
        {
                printf("onvif recev stream_uri probe failed \n");
                onvif_socket_close(onvif_handle_id);
                return false;
        }
        onvif_socket_close(onvif_handle_id);
        printf("%s\n", stream_uri);
        return true;
}
